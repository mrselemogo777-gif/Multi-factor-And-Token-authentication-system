# otp.py - handles one-time passwords for 2FA
# generates 6 digit codes and stores them temporarily

import random
import json
import os
from datetime import datetime, timedelta

OTP_FILE = "otp_codes.json"

# make a random 6 digit code
def generate_otp():
    code = str(random.randint(100000, 999999))
    print(f"\n🔐 [OTP] Your code is: {code}\n")
    return code

# save the OTP code for a user
def save_otp(email, code):
    otps = {}
    if os.path.exists(OTP_FILE):
        f = open(OTP_FILE, 'r')
        otps = json.load(f)
        f.close()
    
    # code expires in 5 minutes
    otps[email] = {
        "code": code,
        "expires": (datetime.utcnow() + timedelta(minutes=5)).isoformat()
    }
    
    f = open(OTP_FILE, 'w')
    json.dump(otps, f, indent=2)
    f.close()

# get the OTP code for a user
def get_otp(email):
    if not os.path.exists(OTP_FILE):
        return None
    
    f = open(OTP_FILE, 'r')
    otps = json.load(f)
    f.close()
    
    if email not in otps:
        return None
    
    return otps[email]['code']

# delete OTP after its used
def delete_otp(email):
    if not os.path.exists(OTP_FILE):
        return
    
    f = open(OTP_FILE, 'r')
    otps = json.load(f)
    f.close()
    
    if email in otps:
        del otps[email]
        f = open(OTP_FILE, 'w')
        json.dump(otps, f, indent=2)
        f.close()
