# config.py - settings for my auth system

SECRET_KEY = "mysecretkey123"
TOKEN_HOURS = 2
PORT = 5003

# my email for sending OTP codes
EMAIL_ADDRESS = "mrselemogo777@gmail.com"
EMAIL_PASSWORD = "ksnd wthw rhnb qmgu"  
