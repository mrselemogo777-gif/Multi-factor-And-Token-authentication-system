# routes.py - handles web pages

from flask import redirect, make_response, request, send_from_directory, session, render_template_string
from datetime import datetime, timedelta
from auth import Auth
from otp import generate_otp, save_otp, get_otp, delete_otp
from config import EMAIL_ADDRESS, EMAIL_PASSWORD
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

auth = Auth()

def send_otp_email(to_email, otp_code, username):
    try:
        msg = MIMEMultipart()
        msg['From'] = EMAIL_ADDRESS
        msg['To'] = to_email
        msg['Subject'] = '🔐 Your OTP Code'
        
        body = f"""Hello {username},

Your OTP code is: {otp_code}

This code will expire in 5 minutes.
"""
        msg.attach(MIMEText(body, 'plain'))
        
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        server.send_message(msg)
        server.quit()
        print(f"✅ Email sent to {to_email}")
        return True
    except Exception as e:
        print(f"❌ Email error: {e}")
        print(f"📧 OTP: {otp_code}")
        return False

def setup_routes(app):
    
    @app.route('/register-page', methods=['GET', 'POST'])
    def register_page():
        if request.method == 'GET':
            return send_from_directory('webpages', 'register.html')
        
        name = request.form.get('name')
        pwd = request.form.get('pwd')
        email = request.form.get('email')
        role = request.form.get('role', 'user')
        
        ok, msg = auth.register(name, pwd, email, role)
        if ok:
            return redirect('/login-page')
        return f"Error: {msg}", 400
    
    @app.route('/login-page', methods=['GET', 'POST'])
    def login_page():
        if request.method == 'GET':
            return send_from_directory('webpages', 'login.html')
        
        name = request.form.get('name')
        pwd = request.form.get('pwd')
        
        ok, msg, username, email = auth.login(name, pwd)
        if not ok:
            return f"Error: {msg}", 401
        
        otp_code = generate_otp()
        save_otp(email, otp_code)
        send_otp_email(email, otp_code, username)
        
        session['temp_username'] = username
        session['temp_email'] = email
        
        with open('webpages/otp.html', 'r') as f:
            html = f.read()
        return html
    
    @app.route('/verify-otp', methods=['POST'])
    def verify_otp():
        username = session.get('temp_username')
        email = session.get('temp_email')
        otp_entered = request.form.get('otp')
        
        if not username:
            return "Session expired. <a href='/login-page'>Login again</a>", 400
        
        stored_otp = get_otp(email)
        
        if not stored_otp or otp_entered != stored_otp:
            return "Invalid or expired OTP. <a href='/login-page'>Try again</a>", 401
        
        delete_otp(email)
        token = auth.create_token(username)
        
        session.pop('temp_username', None)
        session.pop('temp_email', None)
        
        resp = make_response(redirect('/dashboard'))
        resp.set_cookie('auth_token', token, httponly=True, max_age=7200)
        return resp
    
    @app.route('/dashboard')
    def dashboard():
        token = request.cookies.get('auth_token')
        if not token:
            return redirect('/login-page')
        
        valid, msg, data = auth.check(token)
        if not valid:
            return redirect('/login-page')
        
        with open('webpages/dashboard.html', 'r') as f:
            html = f.read()
        
        html = html.replace('NAME_PLACEHOLDER', data.get('user'))
        html = html.replace('PERMS_PLACEHOLDER', ', '.join(data.get('perms')))
        html = html.replace('ROLE_PLACEHOLDER', data.get('role'))
        html = html.replace('EXPIRES_PLACEHOLDER', data.get('expires'))
        html = html.replace('TOKEN_PLACEHOLDER', token)
        
        return html
    
    @app.route('/validate-page', methods=['GET', 'POST'])
    def validate_page():
        result = ''
        
        if request.method == 'POST':
            token = request.form.get('token')
            valid, msg, data = auth.check(token)
            
            if valid:
                result = f'<div class="result valid"><strong>✅ VALID!</strong><br>User: {data.get("user")}<br>Permissions: {", ".join(data.get("perms"))}<br>Role: {data.get("role")}<br>Expires: {data.get("expires")}</div>'
            else:
                result = f'<div class="result invalid"><strong>❌ INVALID!</strong><br>{msg}</div>'
        
        with open('webpages/validate.html', 'r') as f:
            html = f.read()
        
        html = html.replace('RESULT_PLACEHOLDER', result)
        return html
    
    @app.route('/refresh')
    def refresh():
        old_token = request.cookies.get('auth_token')
        if not old_token:
            return redirect('/login-page')
        
        ok, msg, new_token = auth.refresh(old_token)
        if not ok:
            return redirect('/login-page')
        
        resp = make_response(redirect('/dashboard'))
        resp.set_cookie('auth_token', new_token, httponly=True)
        return resp
    
    @app.route('/logout')
    def logout():
        resp = make_response(redirect('/login-page'))
        resp.set_cookie('auth_token', '', expires=0)
        session.clear()
        return resp
    
    @app.route('/')
    def home():
        return redirect('/register-page')
