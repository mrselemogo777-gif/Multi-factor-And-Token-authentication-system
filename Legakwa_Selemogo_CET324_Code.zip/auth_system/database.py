# database.py - handles saving and loading users
# using json file because its simple

import json
import os

USER_FILE = "users.json"

# get all users from the file
def get_users():
    if os.path.exists(USER_FILE):
        f = open(USER_FILE, 'r')
        data = json.load(f)
        f.close()
        return data
    return {}

# save users to the file
def save_users(users):
    f = open(USER_FILE, 'w')
    json.dump(users, f, indent=2)
    f.close()
