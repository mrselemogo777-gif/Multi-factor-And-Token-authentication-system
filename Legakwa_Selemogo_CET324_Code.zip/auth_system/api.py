# api.py - API endpoints for testing with curl
# same as the web pages but returns JSON

from flask import request, jsonify, session
from auth import Auth
from otp import generate_otp, save_otp, get_otp, delete_otp

auth = Auth()

def setup_api(app):
    
    @app.route('/api/register', methods=['POST'])
    def api_register():
        data = request.get_json()
        ok, msg = auth.register(data.get('name'), data.get('pwd'), data.get('email'), data.get('role', 'user'))
        if ok:
            return jsonify({"message": msg}), 201
        return jsonify({"error": msg}), 400
    
    @app.route('/api/login', methods=['POST'])
    def api_login():
        data = request.get_json()
        ok, msg, username, email = auth.login(data.get('name'), data.get('pwd'))
        if not ok:
            return jsonify({"error": msg}), 401
        
        otp_code = generate_otp()
        save_otp(email, otp_code)
        
        session['temp_username'] = username
        session['temp_email'] = email
        
        return jsonify({"message": "OTP sent", "requires_otp": True}), 200
    
    @app.route('/api/verify-otp', methods=['POST'])
    def api_verify_otp():
        data = request.get_json()
        username = session.get('temp_username')
        email = session.get('temp_email')
        otp_entered = data.get('otp')
        
        if not username:
            return jsonify({"error": "Session expired"}), 400
        
        stored_otp = get_otp(email)
        
        if not stored_otp:
            return jsonify({"error": "OTP expired"}), 400
        
        if otp_entered != stored_otp:
            return jsonify({"error": "Invalid OTP"}), 401
        
        delete_otp(email)
        token = auth.create_token(username)
        
        session.pop('temp_username', None)
        session.pop('temp_email', None)
        
        return jsonify({"token": token, "message": "login success"}), 200
    
    @app.route('/api/check', methods=['POST'])
    def api_check():
        data = request.get_json()
        valid, msg, info = auth.check(data.get('token'))
        if valid:
            return jsonify({
                "valid": True,
                "user": info.get('user'),
                "permissions": info.get('perms'),
                "role": info.get('role'),
                "server": info.get('server'),
                "issued": info.get('issued'),
                "expires": info.get('expires')
            }), 200
        return jsonify({"valid": False, "error": msg}), 401
