# app.py - main flask app
# this is where everything starts

from flask import Flask
from routes import setup_routes
from api import setup_api
from config import PORT

app = Flask(__name__)
app.secret_key = "session_secret_123"

# add all my routes
setup_routes(app)
setup_api(app)

# start the server
if __name__ == '__main__':
    app.run(debug=True, port=PORT)
