# auth.py - the main authentication class
# this is where all the login and token stuff happens

import jwt
import bcrypt
import re
from datetime import datetime, timedelta
from database import get_users, save_users
from config import SECRET_KEY, TOKEN_HOURS

class Auth:
    def __init__(self):
        self.secret = SECRET_KEY
        self.expire = TOKEN_HOURS
    
    # check if username has bad characters (private method)
    def _clean_name(self, name):
        if re.match("^[a-zA-Z0-9]+$", name):
            return True
        return False
    
    # make sure password is strong enough
    def _strong_password(self, pwd):
        if len(pwd) < 8:
            return False, "password must be at least 8 characters"
        if not re.search(r"[A-Z]", pwd):
            return False, "password must have an uppercase letter"
        if not re.search(r"[0-9]", pwd):
            return False, "password must have a number"
        return True, "strong"
    
    # register a new user
    def register(self, name, pwd, email, role):
        if not name or not pwd or not email:
            return False, "need name, password and email"
        
        if not self._clean_name(name):
            return False, "username can only have letters and numbers"
        
        # simple email check
        if "@" not in email or "." not in email:
            return False, "please enter a valid email"
        
        strong, msg = self._strong_password(pwd)
        if not strong:
            return False, msg
        
        users = get_users()
        
        if name in users:
            return False, "user already exists"
        
        # set permissions based on role
        if role == "admin":
            perms = ["read", "write", "delete"]
        else:
            perms = ["read"]
        
        # hash the password with bcrypt (adds salt automatically)
        hashed = bcrypt.hashpw(pwd.encode('utf-8'), bcrypt.gensalt())
        
        users[name] = {
            "password": hashed.decode('utf-8'),
            "permissions": perms,
            "role": role,
            "email": email
        }
        save_users(users)
        
        return True, "registered successfully"
    
    # login - check password and return user info
    def login(self, name, pwd):
        users = get_users()
        
        if name not in users:
            return False, "wrong credentials", None, None
        
        stored = users[name]['password'].encode('utf-8')
        if not bcrypt.checkpw(pwd.encode('utf-8'), stored):
            return False, "wrong credentials", None, None
        
        email = users[name].get('email', '')
        return True, "password correct", name, email
    
    # create the JWT token after OTP is verified
    def create_token(self, name):
        users = get_users()
        
        if name not in users:
            return None
        
        now = datetime.utcnow()
        
        # this has all 6 fields the assignment asked for
        token_data = {
            "user": name,
            "perms": users[name]['permissions'],
            "role": users[name]['role'],
            "server": "AuthServer",
            "issued": str(now),
            "expires": str(now + timedelta(hours=self.expire)),
            "id": str(int(now.timestamp()))
        }
        
        # sign the token with HS256 - this stops people from faking it
        token = jwt.encode(token_data, self.secret, algorithm='HS256')
        return token
    
    # check if a token is valid
    def check(self, token):
        if not token:
            return False, "no token", None
        
        try:
            # if someone changed the token, this will fail
            data = jwt.decode(token, self.secret, algorithms=['HS256'])
            return True, "valid", data
        except jwt.ExpiredSignatureError:
            return False, "token expired", None
        except:
            return False, "invalid or modified", None
    
    # get all users (for admin panel)
    def load_users(self):
        return get_users()
    
    # refresh the token
    def refresh(self, old_token):
        valid, msg, data = self.check(old_token)
        if not valid:
            return False, msg, None
        
        now = datetime.utcnow()
        
        new_token_data = {
            "user": data.get('user'),
            "perms": data.get('perms'),
            "role": data.get('role'),
            "server": "AuthServer",
            "issued": str(now),
            "expires": str(now + timedelta(hours=self.expire)),
            "id": str(int(now.timestamp()))
        }
        
        new_token = jwt.encode(new_token_data, self.secret, algorithm='HS256')
        return True, "token refreshed", new_token
